from fastapi import FastAPI

app = FastAPI(title="Demo Api 854Bfa0725")


@app.get("/health")
def health():
    return {
        "status": "ok",
        "service": "demo-api-854bfa0725"
    }


@app.get("/")
def home():
    return {
        "message": "Welcome to Demo Api 854Bfa0725"
    }
