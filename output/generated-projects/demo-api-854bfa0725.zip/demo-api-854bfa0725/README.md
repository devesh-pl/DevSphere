# Demo Api 854Bfa0725

Generated using the DevSphere FastAPI starter template.

## Run locally

Install dependencies:

    python -m pip install -r requirements.txt

Start the application:

    uvicorn main:app --reload

API documentation:

    http://localhost:8000/docs

## Docker

Build the image:

    docker build -t demo-api-854bfa0725 .

Start the container:

    docker run --rm -p 8000:8000 demo-api-854bfa0725

## Health endpoint

GET /health
